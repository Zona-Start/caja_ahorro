import { Module } from '@nestjs/common';
import { LoanWsGateway } from './websocket.gateway';
import { GlobalEventBridgeSubscriber } from './global-event-bridge';

@Module({
  providers: [LoanWsGateway, GlobalEventBridgeSubscriber],
  exports: [LoanWsGateway],
})
export class WsModule {}
